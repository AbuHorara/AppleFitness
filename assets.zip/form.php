<html>
<head>
<title>Sending form data to an Email</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>
<body>
<div class="wrapper" style="width: 35%; margin: 0 auto;">
<form name="mailinfo" method="post" action="sendmail.php" class="form-signin">
<input type="text" name="to" size="40" class="form-control" placeholder="To:" />
<br/>
<input type="text" name="from" size="40" class="form-control"  placeholder="From:" />
<br/>
<input type="text" name="subject" size="40" class="form-control"  placeholder="Subject:" />
<br/>
<textarea cols="50" rows="5" name="message" class="form-control" placeholder="Enter your message">
</textarea>
<br/><br/>
<input class="btn btn-small btn-primary" type="Submit" value="Send"/>
</form>
</div>	
</body>
</html>